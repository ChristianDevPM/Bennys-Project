<?php
// CustomerList.php - Cue Time Systems Customer Management

// Database connection
$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Cue Time Systems - Customer List</title>
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
        .button {
            background-color: #2e4d3e;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9em;
            text-decoration: none;
        }
        .button:hover {
            background-color: #3e6a58;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #87aa9f;
            color: #2e4d3e;
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

<main class="main-content">
    <header class="main-header">
        <h1>Customer List</h1>
    </header>

    <!-- Search Form -->
    <form method="GET" action="CustomerList.php" style="margin-bottom: 1rem;">
        <input type="text" name="search" placeholder="Search by name..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
        <input type="submit" value="Search">
    </form>

    <!-- Action Buttons -->
    <a href="CustomerAdd.php" class="button">Add Customer</a>
    <a class="button no-print" href="ExportCustomerCSV.php">📄 Export CSV</a>

    <!-- Customer Table -->
    <div class="box">
        <table>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Phone Number</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
            <th>Email</th>
        </tr>

            <?php
            try {
                $search = $_GET['search'] ?? '';

if (!empty($search)) {
    $sql = "SELECT CustomerID, FirstName, LastName, PhoneNumber FROM dbo.CUSTOMER 
            WHERE FirstName LIKE :first 
               OR LastName LIKE :last 
               OR PhoneNumber LIKE :phone 
            ORDER BY CustomerID ASC";
    $stmt = $conn->prepare($sql);
    $searchTerm = '%' . $search . '%';
    $stmt->bindValue(':first', $searchTerm, PDO::PARAM_STR);
    $stmt->bindValue(':last', $searchTerm, PDO::PARAM_STR);
    $stmt->bindValue(':phone', $searchTerm, PDO::PARAM_STR);
    $stmt->execute();
} else {
    $sql = "SELECT CustomerID, FirstName, LastName, PhoneNumber FROM dbo.CUSTOMER ORDER BY CustomerID ASC";
    $stmt = $conn->query($sql);
}

$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($customers) {
    foreach ($customers as $row) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['FirstName']) . "</td>";
        echo "<td>" . htmlspecialchars($row['LastName']) . "</td>";
        echo "<td>" . htmlspecialchars($row['PhoneNumber']) . "</td>";
        echo "<td><a href='CustomerView.php?CustomerID=" . $row['CustomerID'] . "'><img src='images/view.png' alt='View' width='15' height='20'></a></td>";
        echo "<td><a href='CustomerEdit.php?CustomerID=" . $row['CustomerID'] . "'><img src='images/edit-icon.png' alt='Edit' width='15' height='20'></a></td>";
        echo "<td><a href='CustomerDelete.php?CustomerID=" . $row['CustomerID'] . "'><img src='images/delete-icon.png' alt='Delete' width='15' height='20'></a></td>";
        echo "<td><a class='button no-print' href='EmailSingleCustomer.php?id=" . $row['CustomerID'] . "'>📧 Email</a></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7'>No customers found.</td></tr>";
}
            } catch (PDOException $e) {
                echo "<tr><td colspan='6'>❌ Error: " . $e->getMessage() . "</td></tr>";
            }
            ?>
        </table>
    </div>
</main>
</body>
</html>