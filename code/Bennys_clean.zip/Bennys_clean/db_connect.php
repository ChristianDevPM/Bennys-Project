<?php
$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>