<?php
require_once 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;

$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

$search = $_GET['search'] ?? '';

$conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "
SELECT 
  c.FirstName,
  c.LastName,
  c.PhoneNumber,
  r.RateName,
  pr.RentalDate,
  pr.TotalPlayers,
  pr.TotalPrice
FROM poolrental pr
JOIN customer c ON pr.CustomerID = c.CustomerID
JOIN rates r ON pr.RateID = r.RateID
WHERE c.FirstName LIKE :first
   OR c.LastName LIKE :last
   OR c.PhoneNumber LIKE :phone
ORDER BY pr.RentalDate DESC
";

$stmt = $conn->prepare($sql);
$searchParam = '%' . $search . '%';
$stmt->bindValue(':first', $searchParam);
$stmt->bindValue(':last', $searchParam);
$stmt->bindValue(':phone', $searchParam);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Build the PDF
$totalRentals = 0;
$totalAmount = 0.00;

$html = "<h2>Customer Rental Report</h2>";
$html .= "<p>Search Term: <strong>" . htmlspecialchars($search) . "</strong></p>";
$html .= "<table border='1' cellspacing='0' cellpadding='5' width='100%'>
<tr>
  <th>Name</th>
  <th>Phone</th>
  <th>Rental Date</th>
  <th>Rate</th>
  <th>Players</th>
  <th>Total Price</th>
</tr>";

foreach ($result as $row) {
    $totalRentals++;
    $totalAmount += $row['TotalPrice'];
    $html .= "<tr>
        <td>" . htmlspecialchars($row['FirstName'] . ' ' . $row['LastName']) . "</td>
        <td>" . htmlspecialchars($row['PhoneNumber']) . "</td>
        <td>" . htmlspecialchars($row['RentalDate']) . "</td>
        <td>" . htmlspecialchars($row['RateName']) . "</td>
        <td>" . htmlspecialchars($row['TotalPlayers']) . "</td>
        <td>$" . number_format($row['TotalPrice'], 2) . "</td>
    </tr>";
}

$html .= "</table><br>";
$html .= "<h4>Total Rentals: $totalRentals</h4>";
$html .= "<h4>Total Amount: $" . number_format($totalAmount, 2) . "</h4>";

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("CustomerRentalReport.pdf", array("Attachment" => true));
?>