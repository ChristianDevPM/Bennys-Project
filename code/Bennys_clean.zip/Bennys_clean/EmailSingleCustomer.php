<?php
$submitted = false;
$subject = $_POST['subject'] ?? '';
$message = $_POST['message'] ?? '';
$customer = null;

$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_GET['id'])) {
        $stmt = $conn->prepare("SELECT FirstName, LastName, EmailAddress FROM customer WHERE CustomerID = :id");
        $stmt->bindValue(':id', $_GET['id'], PDO::PARAM_INT);
        $stmt->execute();
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($subject) && !empty($message) && isset($_POST['email'])) {
        $submitted = true;
    }
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Email Individual Customer</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <style>
    .email-box {
      max-width: 600px;
      background: #fff;
      padding: 30px;
      margin: 40px auto;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .email-box h2 {
      color: #2e4d3e;
    }
    .email-box input[type="text"],
    .email-box textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }
    .email-box textarea {
      height: 120px;
    }
    .email-box input[type="submit"] {
      background: #2e4d3e;
      color: white;
      padding: 10px 20px;
      font-weight: bold;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .email-box input[type="submit"]:hover {
      background: #3e6a58;
    }
    .preview {
      background: #eef6f3;
      padding: 20px;
      border-radius: 10px;
      margin-top: 20px;
    }
    .logo-sig {
      margin-top: 30px;
    }
    .logo-sig img {
      max-height: 50px;
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

<main class="main-content">
  <div class="email-box">
    <?php if ($customer && !$submitted): ?>
      <h2>Email to <?= htmlspecialchars($customer['FirstName'] . ' ' . $customer['LastName']) ?></h2>
      <form method="post">
        <input type="hidden" name="email" value="<?= htmlspecialchars($customer['EmailAddress']) ?>">
        <label for="subject">Subject:</label>
        <input type="text" name="subject" id="subject" required placeholder="Subject" value="<?= htmlspecialchars($subject) ?>">

        <label for="message">Message:</label>
        <textarea name="message" id="message" required placeholder="Your message"><?= htmlspecialchars($message) ?></textarea>

        <input type="submit" value="Send Email">
      </form>

    <?php elseif ($submitted): ?>
      <div class="preview">
        <h3>✅ Mock Email Sent To:</h3>
        <p><strong><?= htmlspecialchars($_POST['email']) ?></strong></p>
        <p><strong>Subject:</strong> <?= htmlspecialchars($subject) ?></p>
        <p><?= nl2br(htmlspecialchars($message)) ?></p>

        <div class="logo-sig">
          <p>Thanks,<br>Benny's Promotions Team</p>
          <img src="images/BennysLogo.png" alt="Benny's Logo">
        </div>
      </div>

    <?php else: ?>
      <p style="color: red;">Customer not found or ID missing.</p>
    <?php endif; ?>
  </div>
</main>
</body>
</html>