<?php
require_once 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;

$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

$startDate = $_GET['start'] ?? date('Y-m-01');
$endDate   = $_GET['end'] ?? date('Y-m-d');

$conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Fetch data
$sql = "
    SELECT pr.RentalDate, pr.RentalStart, pr.RentalEnd, pr.TotalPlayers, pr.TotalPrice,
           CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName, r.RateName
    FROM POOLRENTAL pr
    JOIN CUSTOMER c ON pr.CustomerID = c.CustomerID
    JOIN RATES r ON pr.RateID = r.RateID
    WHERE pr.RentalDate BETWEEN :start AND :end
    ORDER BY pr.RentalDate DESC, pr.RentalStart
";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':start', $startDate);
$stmt->bindParam(':end', $endDate);
$stmt->execute();
$rentals = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals by rate
$totalsByRate = [];
foreach ($rentals as $row) {
    $rate = $row['RateName'];
    $totalsByRate[$rate] = ($totalsByRate[$rate] ?? 0) + $row['TotalPrice'];
}

// Build HTML
$html = "<h2>Rental Summary Report</h2>
<p>From: $startDate to $endDate</p>
<table border='1' cellspacing='0' cellpadding='5' width='100%'>
<tr><th>Date</th><th>Start</th><th>End</th><th>Players</th><th>Customer</th><th>Rate</th><th>Total Price</th></tr>";

foreach ($rentals as $r) {
    $html .= "<tr>
        <td>{$r['RentalDate']}</td>
        <td>" . substr($r['RentalStart'], 0, 5) . "</td>
        <td>" . substr($r['RentalEnd'], 0, 5) . "</td>
        <td>{$r['TotalPlayers']}</td>
        <td>" . htmlspecialchars($r['CustomerName']) . "</td>
        <td>" . htmlspecialchars($r['RateName']) . "</td>
        <td>$" . number_format($r['TotalPrice'], 2) . "</td>
    </tr>";
}
$html .= "</table><br><h3>Total by Rate Type</h3>
<table border='1' cellspacing='0' cellpadding='5' width='50%'>
<tr><th>Rate Name</th><th>Total</th></tr>";

foreach ($totalsByRate as $rate => $total) {
    $html .= "<tr><td>" . htmlspecialchars($rate) . "</td><td>$" . number_format($total, 2) . "</td></tr>";
}
$html .= "</table>";

// Generate PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("RentalSummaryReport.pdf", array("Attachment" => true));
?>