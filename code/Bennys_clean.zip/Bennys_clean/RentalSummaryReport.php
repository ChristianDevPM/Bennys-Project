<?php
// RentalSummaryReport.php

$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

$startDate = $_GET['start'] ?? date('Y-m-01');
$endDate   = $_GET['end'] ?? date('Y-m-d');
$groupByDay = isset($_GET['groupByDay']);

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "
        SELECT 
            pr.RentalDate,
            pr.RentalStart,
            pr.RentalEnd,
            pr.TotalPlayers,
            pr.TotalPrice,
            CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
            r.RateName
        FROM POOLRENTAL pr
        JOIN CUSTOMER c ON pr.CustomerID = c.CustomerID
        JOIN RATES r ON pr.RateID = r.RateID
        WHERE pr.RentalDate BETWEEN :start AND :end
        ORDER BY pr.RentalDate ASC, pr.RentalStart
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':start', $startDate);
    $stmt->bindParam(':end', $endDate);
    $stmt->execute();
    $rentals = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $totalsByRate = [];
    $grandTotal = 0;

    foreach ($rentals as $row) {
        $rate = $row['RateName'];
        $totalsByRate[$rate] = ($totalsByRate[$rate] ?? 0) + $row['TotalPrice'];
        $grandTotal += $row['TotalPrice'];
    }

} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Cue Time Systems - Rental Summary Report</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
        .report-box {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
        }
        .report-filters {
            margin-bottom: 20px;
        }
        .report-filters input[type="date"],
        .report-filters input[type="submit"],
        .report-filters label {
            padding: 6px;
            margin-right: 10px;
        }
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .report-table th, .report-table td {
            border: 1px solid #ccc;
            padding: 10px;
        }
        .report-table th {
            background-color: #87aa9f;
            color: #2e4d3e;
        }
        .report-summary {
            margin-top: 30px;
        }
        .daily-header {
            margin-top: 30px;
            font-weight: bold;
            font-size: 1.2em;
            color: #2e4d3e;
            border-bottom: 2px solid #ccc;
            padding-bottom: 5px;
        }
        .customer-line {
            margin-left: 20px;
            font-size: 1em;
        }
        .day-total-line {
            margin-left: 20px;
            font-weight: bold;
            color: #333;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

<main class="main-content">
    <header class="main-header">
        <h1>Rental Report</h1>
    </header>

    <div class="report-box">
        <form method="get" class="report-filters" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div style="display: flex; align-items: center; flex-wrap: wrap; gap: 10px;">
                <label for="start">Start Date:</label>
                <input type="date" id="start" name="start" value="<?= htmlspecialchars($startDate) ?>">

                <label for="end">End Date:</label>
                <input type="date" id="end" name="end" value="<?= htmlspecialchars($endDate) ?>">

                <label>
                    <input type="checkbox" name="groupByDay" value="1" <?= $groupByDay ? 'checked' : '' ?>>
                    Group by Day
                </label>

                <input type="submit" value="Filter" class="button">
                <a class="button no-print" href="RentalSummaryReport.php">Reset</a>
            </div>

            <div style="display: flex; gap: 10px;">
                <a class="button no-print" href="RentalSummaryPDF.php?start=<?= urlencode($startDate) ?>&end=<?= urlencode($endDate) ?>" target="_blank">🖨️ PDF</a>
                <a class="button no-print" href="ExportRentalSummaryCSV.php?start=<?= urlencode($startDate) ?>&end=<?= urlencode($endDate) ?>">📤 Export CSV</a>
            </div>
        </form>

        <div class="report-summary">
             <h3>Total by Rate Type</h3>
            <table class="report-table">
                <thead>
                <tr>
                    <th>Rate Name</th>
                    <th>Total Amount</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($totalsByRate as $rate => $total): ?>
                <tr>
                    <td><?= htmlspecialchars($rate) ?></td>
                    <td>$<?= number_format($total, 2) ?></td>
                </tr>
                <?php endforeach; ?>
                <tr>
                    <th>Grand Total</th>
                    <th>$<?= number_format($grandTotal, 2) ?></th>
                </tr>
            </tbody>
            </table>
        </div>

        <?php if ($groupByDay): ?>

            <?php 
            $dailyData = [];
            foreach ($rentals as $rental) {
                $date = date('Y-m-d', strtotime($rental['RentalDate']));
                $dailyData[$date][] = $rental;
            }
            ?>

            <?php foreach ($dailyData as $date => $dayRentals): ?>
                <div class="daily-header">====== <?= htmlspecialchars(date('F j, Y', strtotime($date))) ?> ======</div>
                <?php 
                $dayTotal = 0;
                foreach ($dayRentals as $rental): 
                    $dayTotal += $rental['TotalPrice'];
                ?>
                    <div class="customer-line"><?= htmlspecialchars($rental['CustomerName']) ?> - $<?= number_format($rental['TotalPrice'], 2) ?></div>
                <?php endforeach; ?>
                <div class="day-total-line">Day Total: $<?= number_format($dayTotal, 2) ?></div>
            <?php endforeach; ?>

        <?php else: ?>

            <table class="report-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Players</th>
                        <th>Customer</th>
                        <th>Rate</th>
                        <th>Total Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rentals as $rental): ?>
                    <tr>
                        <td><?= htmlspecialchars(date('Y-m-d', strtotime($rental['RentalDate']))) ?></td>
                        <td><?= htmlspecialchars(substr($rental['RentalStart'], 0, 5)) ?></td>
                        <td><?= htmlspecialchars(substr($rental['RentalEnd'], 0, 5)) ?></td>
                        <td><?= htmlspecialchars($rental['TotalPlayers']) ?></td>
                        <td><?= htmlspecialchars($rental['CustomerName']) ?></td>
                        <td><?= htmlspecialchars($rental['RateName']) ?></td>
                        <td>$<?= number_format($rental['TotalPrice'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        <?php endif; ?>

    </div>
</main>

</body>
</html>