<?php
// RentalSummaryReport.php

$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

$startDate = $_GET['start'] ?? date('Y-m-01');
$endDate   = $_GET['end'] ?? date('Y-m-d');

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "
        SELECT 
            pr.RentalDate,
            pr.RentalStart,
            pr.RentalEnd,
            pr.TotalPlayers,
            pr.TotalPrice,
            CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
            r.RateName
        FROM POOLRENTAL pr
        JOIN CUSTOMER c ON pr.CustomerID = c.CustomerID
        JOIN RATES r ON pr.RateID = r.RateID
        WHERE pr.RentalDate BETWEEN :start AND :end
        ORDER BY pr.RentalDate DESC, pr.RentalStart
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':start', $startDate);
    $stmt->bindParam(':end', $endDate);
    $stmt->execute();
    $rentals = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $totalsByRate = [];
    foreach ($rentals as $row) {
        $rate = $row['RateName'];
        $totalsByRate[$rate] = ($totalsByRate[$rate] ?? 0) + $row['TotalPrice'];
    }

} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Cue Time Systems - Rental Summary Report</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
        .report-box {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
        }
        .report-filters {
            margin-bottom: 20px;
        }
        .report-filters input[type="date"],
        .report-filters input[type="submit"] {
            padding: 6px;
            margin-right: 10px;
        }
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .report-table th, .report-table td {
            border: 1px solid #ccc;
            padding: 10px;
        }
        .report-table th {
            background-color: #87aa9f;
            color: #2e4d3e;
        }
        .report-summary {
            margin-top: 30px;
        }
        .report-summary h3 {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

    <main class="main-content">
        <header class="main-header">
            <h1>Rental Report</h1>
        </header>

        <div class="report-box">
        <form method="get" class="report-filters" style="display: flex; align-items: center; gap: 10px;">
            <label for="start">Start Date:</label>
            <input type="date" id="start" name="start" value="<?= htmlspecialchars($startDate) ?>">

            <label for="end">End Date:</label>
            <input type="date" id="end" name="end" value="<?= htmlspecialchars($endDate) ?>">

            <input type="submit" value="Filter" class="button">
            <a class="button no-print" href="RentalSummaryReport.php">Reset</a>
            
            <div style="display: flex; justify-content: space-between; align-items: center;">
            <p style="margin: 0; font-weight: normal;">
                
            <!-- Moved Print to PDF into form row -->
                <a class="button no-print" href="RentalSummaryPDF.php?start=<?= urlencode($startDate) ?>&end=<?= urlencode($endDate) ?>" target="_blank">
                    🖨️ PDF
                </a>

                <a class="button no-print" 
                    style="margin-left: 10px;"
                    href="ExportRentalSummaryCSV.php?start=<?= urlencode($startDate) ?>&end=<?= urlencode($endDate) ?>">
                    📤 Export CSV
                </a>
            </p>
        </div>
        </form>

            <table class="report-table">
                <tr>
                    <th>Date</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Players</th>
                    <th>Customer</th>
                    <th>Rate</th>
                    <th>Total Price</th>
                </tr>
                <?php foreach ($rentals as $rental): ?>
                <tr>
                    <td><?= htmlspecialchars(date('Y-m-d', strtotime($rental['RentalDate']))) ?></td>
                    <td><?= htmlspecialchars(substr($rental['RentalStart'], 0, 5)) ?></td>
                    <td><?= htmlspecialchars(substr($rental['RentalEnd'], 0, 5)) ?></td>
                    <td><?= htmlspecialchars($rental['TotalPlayers']) ?></td>
                    <td><?= htmlspecialchars($rental['CustomerName']) ?></td>
                    <td><?= htmlspecialchars($rental['RateName']) ?></td>
                    <td>$<?= number_format($rental['TotalPrice'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </table>

            <div class="report-summary">
    <h3>Total by Rate Type</h3>
    <table class="report-table">
        <thead>
            <tr>
                <th>Rate Name</th>
                <th>Total Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($totalsByRate as $rate => $total): ?>
            <tr>
                <td><?= htmlspecialchars($rate) ?></td>
                <td>$<?= number_format($total, 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
        </div>
    </main>
</body>
</html>