<?php
$CustomerID = intval($_GET['CustomerID'] ?? $_POST['CustomerID'] ?? 0);
$FirstName = $LastName = "";
$deleted = false;
$message = "";

// Azure SQL connection settings
$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // If form was submitted via POST, perform delete
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $CustomerID > 0) {
        $stmt = $conn->prepare("DELETE FROM customer WHERE CustomerID = :CustomerID");
        $stmt->bindParam(':CustomerID', $CustomerID, PDO::PARAM_INT);
        if ($stmt->execute()) {
            header("Location: CustomerList.php");
            exit();
        } else {
            $message = "Failed to delete customer.";
        }
    }

    // Preload customer name for confirmation
    if ($CustomerID > 0) {
        $stmt = $conn->prepare("SELECT FirstName, LastName FROM customer WHERE CustomerID = :CustomerID");
        $stmt->bindParam(':CustomerID', $CustomerID, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $FirstName = $row['FirstName'];
            $LastName = $row['LastName'];
        }
    }

} catch (PDOException $e) {
    $message = "Connection failed: " . $e->getMessage();
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Cue Time Systems - Delete Customer</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
        .confirm-box {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
        }
        .confirm-box h2 {
            text-align: center;
            color: #2e4d3e;
            margin-bottom: 20px;
        }
        .confirm-box p {
            text-align: center;
            font-size: 1.1rem;
            margin-bottom: 30px;
        }
        .confirm-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        .main-header h1 {
            text-align: center;
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

    <main class="main-content">
        <header class="main-header">
            <h1>Delete Customer</h1>
        </header>

        <div class="confirm-box">
            <h2>Confirm Deletion</h2>
            <?php if (!empty($FirstName)): ?>
                <p>Are you sure you want to delete <strong><?= htmlspecialchars($FirstName . ' ' . $LastName) ?></strong>?</p>
                <form action="CustomerDelete.php" method="post">
                    <input type="hidden" name="CustomerID" value="<?= $CustomerID ?>">
                    <div class="confirm-buttons">
                        <input type="submit" value="Yes, Delete" class="button">
                        <a href="CustomerList.php" class="button">Cancel</a>
                    </div>
                </form>
            <?php else: ?>
                <p>No customer found to delete.</p>
                <div class="confirm-buttons">
                    <a href="CustomerList.php" class="button">Back to List</a>
                </div>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>