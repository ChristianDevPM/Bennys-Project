<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $FirstName    = $_POST['FirstName'];
    $LastName     = $_POST['LastName'];
    $PhoneNumber  = $_POST['PhoneNumber'];
    $EmailAddress = $_POST['EmailAddress'];
    $LeagueName   = $_POST['LeagueName'];

    // Azure SQL connection
    $server   = 'tcp:mis4173.database.windows.net,1433';
    $database = 'bennys';
    $username = 'bennysadmin';
    $password = 'Poolhall1!';

    try {
        $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "INSERT INTO customer (FirstName, LastName, PhoneNumber, EmailAddress, LeagueName)
                VALUES (:FirstName, :LastName, :PhoneNumber, :EmailAddress, :LeagueName)";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':FirstName', $FirstName);
        $stmt->bindParam(':LastName', $LastName);
        $stmt->bindParam(':PhoneNumber', $PhoneNumber);
        $stmt->bindParam(':EmailAddress', $EmailAddress);
        $stmt->bindParam(':LeagueName', $LeagueName);

        if ($stmt->execute()) {
            header("Location: CustomerList.php");
            exit();
        } else {
            echo "<h2>Error adding customer.</h2>";
        }
    } catch (PDOException $e) {
        echo "<h2>Connection failed: " . $e->getMessage() . "</h2>";
    }
} else {
    echo "<h2>Invalid request.</h2>";
}
?>
