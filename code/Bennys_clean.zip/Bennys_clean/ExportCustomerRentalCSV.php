<?php
$search = $_GET['search'] ?? '';

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=CustomerRentalReport.csv');

$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

$conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "
SELECT 
  c.FirstName,
  c.LastName,
  c.PhoneNumber,
  r.RateName,
  pr.RentalDate,
  pr.TotalPlayers,
  pr.TotalPrice
FROM poolrental pr
JOIN customer c ON pr.CustomerID = c.CustomerID
JOIN rates r ON pr.RateID = r.RateID
WHERE c.FirstName LIKE :first
   OR c.LastName LIKE :last
   OR c.PhoneNumber LIKE :phone
ORDER BY pr.RentalDate DESC
";

$stmt = $conn->prepare($sql);
$searchParam = '%' . $search . '%';
$stmt->bindValue(':first', $searchParam);
$stmt->bindValue(':last', $searchParam);
$stmt->bindValue(':phone', $searchParam);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

$output = fopen('php://output', 'w');
fputcsv($output, ['Name', 'Phone', 'Rental Date', 'Rate', 'Total Players', 'Total Price']);

foreach ($results as $row) {
    fputcsv($output, [
        $row['FirstName'] . ' ' . $row['LastName'],
        $row['PhoneNumber'],
        $row['RentalDate'],
        $row['RateName'],
        $row['TotalPlayers'],
        number_format($row['TotalPrice'], 2)
    ]);
}
fclose($output);
exit;
?>