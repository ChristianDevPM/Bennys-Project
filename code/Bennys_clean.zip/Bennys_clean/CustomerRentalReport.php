<?php
require_once 'db_connect.php';

$search = $_POST['search'] ?? '';

$sql = "
SELECT 
  c.FirstName,
  c.LastName,
  c.PhoneNumber,
  r.RateName,
  pr.RentalDate,
  pr.TotalPlayers,
  pr.TotalPrice
FROM poolrental pr
JOIN customer c ON pr.CustomerID = c.CustomerID
JOIN rates r ON pr.RateID = r.RateID
WHERE c.FirstName LIKE :first
   OR c.LastName LIKE :last
   OR c.PhoneNumber LIKE :phone
ORDER BY pr.RentalDate DESC
";

$stmt = $conn->prepare($sql);
$searchParam = '%' . $search . '%';
$stmt->bindValue(':first', $searchParam);
$stmt->bindValue(':last', $searchParam);
$stmt->bindValue(':phone', $searchParam);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Customer Rental Report</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <style>
    .report-box {
        background-color: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
        margin: 20px auto;
    }
    .report-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }
    .report-table th, .report-table td {
        border: 1px solid #ccc;
        padding: 10px;
    }
    .report-table th {
        background-color: #87aa9f;
        color: #2e4d3e;
    }
    .no-print {
        margin-top: 10px;
        display: inline-block;
    }
    @media print {
      .no-print {
        display: none;
      }
    }
  </style>
</head>
<body>
  <?php include 'sidebar.php'; ?>
  <main class="main-content">
    <header class="main-header">
      <h1>Customer Rental Report</h1>
    </header>

    <div class="report-box">
  <?php if (!empty($search)): ?>
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <p style="margin: 0; font-weight: bold;">
        Results for "<em><?= htmlspecialchars($search) ?></em>"
      </p>
      <div style="display: flex; gap: 10px;">
        <a class="button no-print" 
           href="CustomerRentalPDF.php?search=<?= urlencode($search) ?>" 
           target="_blank">
           🖨️ PDF
        </a>
        <a class="button no-print"
           href="ExportCustomerRentalCSV.php?search=<?= urlencode($search) ?>">
           📤 CSV
        </a>
      </div>
    </div>
  <?php endif; ?>
</div>


      <table class="report-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Phone</th>
            <th>Rental Date</th>
            <th>Rate</th>
            <th>Total Players</th>
            <th>Total Price</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $totalRentals = 0;
          $totalAmount = 0.00;
          foreach ($result as $row):
              $totalRentals++;
              $totalAmount += $row['TotalPrice'];
          ?>
          <tr>
            <td><?= htmlspecialchars($row['FirstName'] . ' ' . $row['LastName']) ?></td>
            <td><?= htmlspecialchars($row['PhoneNumber']) ?></td>
            <td><?= htmlspecialchars($row['RentalDate']) ?></td>
            <td><?= htmlspecialchars($row['RateName']) ?></td>
            <td><?= htmlspecialchars($row['TotalPlayers']) ?></td>
            <td>$<?= number_format($row['TotalPrice'], 2) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr>
            <th colspan="4" style="text-align:right;">Total Rentals:</th>
            <td colspan="2"><?= $totalRentals ?></td>
          </tr>
          <tr>
            <th colspan="4" style="text-align:right;">Total Amount:</th>
            <td colspan="2">$<?= number_format($totalAmount, 2) ?></td>
          </tr>
        </tfoot>
      </table>
    </div>
    <div class="form-actions" style="margin-top: 1rem;">
    
         <a href="CustomerRentalSearch.php" class="button" style="margin-left: 10px;">Cancel</a>
    </div>
  </main>
</body>
</html>