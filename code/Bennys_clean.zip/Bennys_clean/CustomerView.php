<?php
// CustomerView.php

$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

$customerID = $_GET['CustomerID'] ?? null;

if (!$customerID) {
    die("Customer ID is missing.");
}

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("SELECT FirstName, LastName, PhoneNumber, EmailAddress, LeagueName FROM customer WHERE CustomerID = :CustomerID");
    $stmt->bindParam(':CustomerID', $customerID, PDO::PARAM_INT);
    $stmt->execute();
    $customer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$customer) {
        die("Customer not found.");
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Cue Time Systems - View Customer</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
        .two-column {
            display: grid;
            grid-template-columns: 150px 1fr;
            gap: 10px 20px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
        }
        .two-column .label {
            font-weight: 600;
            color: #2e4d3e;
        }
        .main-header h1 {
            text-align: center;
        }
        .button-row {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

    <main class="main-content">
        <header class="main-header">
            <h1>Customer Details</h1>
        </header>

        <div class="box">
            <div class="two-column">
                <div class="label">First Name:</div>
                <div><?= htmlspecialchars($customer['FirstName']) ?></div>

                <div class="label">Last Name:</div>
                <div><?= htmlspecialchars($customer['LastName']) ?></div>

                <div class="label">Phone Number:</div>
                <div><?= htmlspecialchars($customer['PhoneNumber']) ?></div>

                <div class="label">Email Address:</div>
                <div><?= htmlspecialchars($customer['EmailAddress']) ?></div>

                <div class="label">League Name:</div>
                <div><?= htmlspecialchars($customer['LeagueName']) ?></div>
            </div>

            <div class="button-row">
                <a href="CustomerEdit.php?CustomerID=<?= $customerID ?>" class="button">Edit</a>
                <a href="CustomerList.php" class="button">Back to List</a>
            </div>
        </div>
    </main>
</body>
</html>