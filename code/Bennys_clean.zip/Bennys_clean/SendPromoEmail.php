<?php
$submitted = false;
$subject = $_POST['subject'] ?? '';
$message = $_POST['message'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($subject) && !empty($message)) {
        $submitted = true;
    
        $uploadedFileName = '';
        if (!empty($_FILES['attachment']['name'])) {
            $uploadedFileName = basename($_FILES['attachment']['name']);
            $uploadedTempPath = $_FILES['attachment']['tmp_name'];
    
            // Create uploads folder if it doesn't exist
            $targetDir = "uploads/";
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0755);
            }
    
            $targetPath = $targetDir . $uploadedFileName;
            move_uploaded_file($uploadedTempPath, $targetPath);
        }
}


function getCustomers() {
    $server   = 'tcp:mis4173.database.windows.net,1433';
    $database = 'bennys';
    $username = 'bennysadmin';
    $password = 'Poolhall1!';

    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("SELECT FirstName, LastName, EmailAddress FROM customer WHERE EmailAddress IS NOT NULL AND EmailAddress <> ''");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mock Email to Customer List</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <style>
    .promo-form {
      max-width: 600px;
      margin: 40px auto;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .promo-form h2 {
      margin-top: 0;
      color: #2e4d3e;
    }
    .promo-form input[type="text"],
    .promo-form textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    .promo-form textarea {
      height: 120px;
    }
    .promo-form input[type="submit"] {
      background: #2e4d3e;
      color: white;
      padding: 10px 20px;
      border: none;
      font-weight: bold;
      border-radius: 5px;
      cursor: pointer;
    }
    .promo-form input[type="submit"]:hover {
      background: #3e6a58;
    }
    .mock-email-preview {
      background: #eef6f3;
      padding: 20px;
      border-radius: 10px;
      margin: 30px auto;
      max-width: 800px;
    }
    .mock-email-preview h3 {
      margin-top: 0;
    }
    .logo-sig {
      margin-top: 30px;
    }
    .logo-sig img {
      max-height: 50px;
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

<main class="main-content">
  <div class="promo-form">
    <h2>Send Benny's Specials (Mock)</h2>
    <form method="post" enctype="multipart/form-data">
      <label for="subject">Subject:</label>
      <input type="text" id="subject" name="subject" required placeholder="Subject of your email" value="<?= htmlspecialchars($subject) ?>">

      <label for="message">Message:</label>
      <textarea id="message" name="message" required placeholder="Type your message here"><?= htmlspecialchars($message) ?></textarea>
      <label for="attachment">Attach image or file (PDF, JPG, PNG):</label>
        <input type="file" name="attachment" id="attachment" accept=".pdf,.jpg,.jpeg,.png">  
      <input type="submit" value="Send to Customer List">
    </form>
  </div>

  <?php if ($submitted): ?>
    <div class="mock-email-preview">
      <h3>✅ Mock Email Sent to:</h3>
      <ul>
        <?php
        $customers = getCustomers();
        foreach ($customers as $cust) {
            echo "<li>" . htmlspecialchars($cust['EmailAddress']) . "</li>";
        }
        ?>
      </ul>

      <h3>Email Preview:</h3>
      <p><strong>Subject:</strong> <?= htmlspecialchars($subject) ?></p>
      <p><?= nl2br(htmlspecialchars($message)) ?></p>
      <?php if (!empty($uploadedFileName)): ?>
        <p><strong>Attached File:</strong> <?= htmlspecialchars($uploadedFileName) ?></p>

         <?php if (preg_match('/\.(jpg|jpeg|png)$/i', $uploadedFileName)): ?>
        <p><strong>Image Preview:</strong></p>
        <img src="uploads/<?= urlencode($uploadedFileName) ?>" style="max-width: 100%; height: auto; margin-top: 10px;" alt="Attached Image">
    <?php endif; ?>
<?php endif; ?> 
      <div class="logo-sig">
        <p>Thanks,<br>Benny's Promotions Team</p>
        <img src="images/BennysLogo.png" alt="Benny's Logo">
      </div>
    </div>
  <?php endif; ?>
</main>
</body>
</html>