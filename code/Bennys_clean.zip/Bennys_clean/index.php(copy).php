<?php
// Azure DB connection for dashboard
$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Cue Time Systems - Dashboard</title>
  <link rel="stylesheet" href="assets/css/style.css" />

  
</head>
<body>
<?php include 'sidebar.php'; ?>

  <main class="main-content">
  <header class="main-header" style="text-align: center;">
    <div>
      <h1>Welcome to Cue Time Systems</h1><br>
      <p><strong>Your centralized dashboard for customer and pool rental management.</strong></p>
      <div class="banner-container" style="display: flex; justify-content: center; margin-top: 20px;">
        <img src="images/bannerballs.png" alt="Pool Balls Banner 1" style="width: 20%; height: auto;">
        <img src="images/bannerballs.png" alt="Pool Balls Banner 2" style="width: 20%; height: auto;">
        <img src="images/bannerballs.png" alt="Pool Balls Banner 3" style="width: 20%; height: auto;">
    </div>
</header>

    <section class="dashboard-cards">
      <div class="card">
        <h2>Customer Database</h2>
        <p><a href="CustomerList.php">View Customer List</a></p>
      </div>

      <div class="card">
        <h2>Reports</h2>
        <p><a href="RentalSummaryReport.php">View rental summary</a></p>
      </div>

      <div class="card">
        <h2>Manage Pool Time Rates</h2>
        <p><a href="ManageRates.php">View/Edit Pool Rates</a></p>
      </div>

    </section>
    
    <section class="pool-grid">
       <h2 style="text-align: center; margin-top: 2rem;">Table Availability</h2>
        <div class="pool-grid-container">
      <?php for ($i = 1; $i <= 10; $i++): ?>
      <div class="pool-card">
        <p><strong>Table <?= $i ?></strong></p>
        <p>Status: Unknown</p>
      </div>
        <?php endfor; ?>
          </div>
    </section>

  </main>
</body>
</html>