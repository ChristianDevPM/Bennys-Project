<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $CustomerID   = intval($_POST['CustomerID']);
    $FirstName    = $_POST['FirstName'];
    $LastName     = $_POST['LastName'];
    $PhoneNumber  = $_POST['PhoneNumber'];
    $EmailAddress = $_POST['EmailAddress'];
    $LeagueName   = $_POST['LeagueName'];

    // Azure SQL connection
    $server   = 'tcp:mis4173.database.windows.net,1433';
    $database = 'bennys';
    $username = 'bennysadmin';
    $password = 'Poolhall1!';

    try {
        $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "UPDATE customer
                SET FirstName = :FirstName,
                    LastName = :LastName,
                    PhoneNumber = :PhoneNumber,
                    EmailAddress = :EmailAddress,
                    LeagueName = :LeagueName
                WHERE CustomerID = :CustomerID";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':FirstName', $FirstName);
        $stmt->bindParam(':LastName', $LastName);
        $stmt->bindParam(':PhoneNumber', $PhoneNumber);
        $stmt->bindParam(':EmailAddress', $EmailAddress);
        $stmt->bindParam(':LeagueName', $LeagueName);
        $stmt->bindParam(':CustomerID', $CustomerID, PDO::PARAM_INT);

        if ($stmt->execute()) {
            header("Location: CustomerList.php");
            exit();
        } else {
            echo "<h2>Error updating customer.</h2>";
        }

    } catch (PDOException $e) {
        echo "<h2>Connection failed: " . $e->getMessage() . "</h2>";
    }
} else {
    echo "<h2>Invalid request.</h2>";
}
?>
