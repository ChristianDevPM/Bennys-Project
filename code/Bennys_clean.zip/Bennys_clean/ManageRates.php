<?php
// ManageRates.php
$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save'])) {
    $rateID = $_POST['rate_id'];
    $rateName = $_POST['rate_name'];
    $rateValue = $_POST['rate'];

    $stmt = $conn->prepare("UPDATE rates SET RateName = :rateName, Rate = :rateValue WHERE RateID = :rateID");
    $stmt->bindParam(':rateName', $rateName);
    $stmt->bindParam(':rateValue', $rateValue);
    $stmt->bindParam(':rateID', $rateID);
    $stmt->execute();
}

$stmt = $conn->query("SELECT * FROM rates ORDER BY RateID ASC");
$rates = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Cue Time Systems - Manage Rates</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
        .button {
            background-color: #2e4d3e;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9em;
            text-decoration: none;
        }

        .button:hover {
            background-color: #3e6a58;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #87aa9f;
            color: #2e4d3e;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 5px;
        }

        .save-btn {
            padding: 5px 10px;
            background-color: #2e4d3e;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .save-btn:hover {
            background-color: #3e6a58;
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

<main class="main-content">
    <header class="main-header">
        <h1>Manage Pool Table Rental Rates</h1>
    </header>

    <div class="box">
        <table>
            <tr>
                <th>Rate ID</th>
                <th>Rate Name</th>
                <th>Rate ($)</th>
                <th>Action</th>
            </tr>
            <?php foreach ($rates as $row) { ?>
            <tr>
                <form method="post" action="ManageRates.php">
                    <td><?= $row['RateID']; ?></td>
                    <td>
                        <input type="text" name="rate_name" value="<?= htmlspecialchars($row['RateName']); ?>">
                    </td>
                    <td>
                        <input type="number" name="rate" step="0.01" value="<?= number_format($row['Rate'], 2); ?>">
                    </td>
                    <td>
                        <input type="hidden" name="rate_id" value="<?= $row['RateID']; ?>">
                        <button type="submit" name="save" class="save-btn">Save</button>
                    </td>
                </form>
            </tr>
            <?php } ?>
        </table>
    </div>
</main>
</body>
</html>