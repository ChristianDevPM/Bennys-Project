<?php
if (!isset($_GET['CustomerID'])) {
    echo "<h2>No Customer ID Provided</h2>";
    exit();
}

$CustomerID = intval($_GET['CustomerID']);

// Azure SQL DB connection
$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("SELECT * FROM customer WHERE CustomerID = :CustomerID");
    $stmt->bindParam(':CustomerID', $CustomerID, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo "<h2>Customer not found.</h2>";
        exit();
    }

} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Cue Time Systems - Edit Customer</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .form-grid label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        .form-grid input[type="text"],
        .form-grid input[type="email"] {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .form-actions {
            text-align: center;
            margin-top: 30px;
        }
        .main-header h1 {
            text-align: center;
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

    <main class="main-content">
        <header class="main-header">
            <h1>Edit Customer</h1>
        </header>

        <div class="box">
            <form action="CustomerUpdateProcessing.php" method="post">
                <input type="hidden" name="CustomerID" value="<?= htmlspecialchars($CustomerID) ?>">

                <div class="form-grid">
                    <div>
                        <label for="FirstName">First Name:</label>
                        <input type="text" id="FirstName" name="FirstName" value="<?= htmlspecialchars($row['FirstName']) ?>" required>
                    </div>
                    <div>
                        <label for="LastName">Last Name:</label>
                        <input type="text" id="LastName" name="LastName" value="<?= htmlspecialchars($row['LastName']) ?>" required>
                    </div>
                    <div>
                        <label for="PhoneNumber">Phone Number:</label>
                        <input type="text" id="PhoneNumber" name="PhoneNumber" value="<?= htmlspecialchars($row['PhoneNumber']) ?>" required>
                    </div>
                    <div>
                        <label for="EmailAddress">Email Address:</label>
                        <input type="email" id="EmailAddress" name="EmailAddress" value="<?= htmlspecialchars($row['EmailAddress']) ?>" required>
                    </div>
                    <div>
                        <label for="LeagueName">League Name:</label>
                        <input type="text" id="LeagueName" name="LeagueName" value="<?= htmlspecialchars($row['LeagueName']) ?>">
                    </div>
                </div>

                <div class="form-actions">
                    <input type="submit" value="Update" class="button">
                </div>
            </form>
        </div>
    </main>
</body>
</html>