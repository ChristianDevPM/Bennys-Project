<?php
// Azure DB connection
$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

try {
    $conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get the POST data
    $tableID = $_POST['TableID'] ?? null;
    $isAvailable = $_POST['IsAvailable'] ?? null;

    // Validate the POST data
    if ($tableID !== null && ($isAvailable === '0' || $isAvailable === '1')) {
        // Update the IsAvailable status
        $sql = "UPDATE dbo.POOLTABLES SET IsAvailable = :isAvailable WHERE TableID = :tableID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':isAvailable', $isAvailable, PDO::PARAM_INT);
        $stmt->bindParam(':tableID', $tableID, PDO::PARAM_INT);
        $stmt->execute();

        // Redirect back to the main page
        header("Location: index.php");
        exit;
    } else {
        echo "Invalid request. Please ensure all fields are filled correctly.";
    }
} catch (PDOException $e) {
    die("❌ Error: " . $e->getMessage());
}
?>