<?php
$startDate = $_GET['start'] ?? date('Y-m-01');
$endDate = $_GET['end'] ?? date('Y-m-d');

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=RentalSummaryReport.csv');

$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

$conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "
SELECT 
  pr.RentalDate,
  pr.RentalStart,
  pr.RentalEnd,
  pr.TotalPlayers,
  pr.TotalPrice,
  CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
  r.RateName
FROM POOLRENTAL pr
JOIN CUSTOMER c ON pr.CustomerID = c.CustomerID
JOIN RATES r ON pr.RateID = r.RateID
WHERE pr.RentalDate BETWEEN :start AND :end
ORDER BY pr.RentalDate DESC, pr.RentalStart
";

$stmt = $conn->prepare($sql);
$stmt->bindParam(':start', $startDate);
$stmt->bindParam(':end', $endDate);
$stmt->execute();
$rentals = $stmt->fetchAll(PDO::FETCH_ASSOC);

$output = fopen('php://output', 'w');
fputcsv($output, ['Date', 'Start Time', 'End Time', 'Players', 'Customer', 'Rate', 'Total Price']);

foreach ($rentals as $rental) {
    fputcsv($output, [
        $rental['RentalDate'],
        substr($rental['RentalStart'], 0, 5),
        substr($rental['RentalEnd'], 0, 5),
        $rental['TotalPlayers'],
        $rental['CustomerName'],
        $rental['RateName'],
        number_format($rental['TotalPrice'], 2)
    ]);
}
fclose($output);
exit;
?>