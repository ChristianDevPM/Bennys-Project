<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Cue Time Systems - Dashboard</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <style>
   /* body {
      background-color: #f2e4d5; /* Creamy beige */
     /* margin: 0;
      font-family: sans-serif;
    } */

    .sidebar {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .dashboard-cards {
      display: flex;
      flex-wrap: wrap;
      gap: 40px;
      justify-content: center;
      padding: 40px 20px;
    }

    .card {
      background-color: #ffffff; /* White cards */
      padding: 30px;
      border-radius: 6px; /* Squared with slight softness */
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
      width: 300px;
      text-align: center;
    }

    .card h2 {
      margin-top: 0;
      color: #2e4d3e;
      font-size: 1.4em;
    }

    .card a {
      color: #2e4d3e;
      text-decoration: none;
      font-weight: 600;
      font-size: 1.1em;
    }

    .card a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

  <main class="main-content">
    <header class="main-header">
      <h1>Welcome to Cue Time Systems</h1>
      <p>Your centralized dashboard for customer and pool rental management.</p>
    </header>

    <section class="dashboard-cards">
      <div class="card">
        <h2>Customer Database</h2>
        <p><a href="CustomerList.php">View all customers</a></p>
      </div>

      <div class="card">
        <h2>Reports</h2>
        <p><a href="RentalSummaryReport.php">View rental summary</a></p>
      </div>
    </section>
  </main>
</body>
</html>