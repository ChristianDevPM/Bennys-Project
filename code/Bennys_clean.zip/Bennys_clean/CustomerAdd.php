<!DOCTYPE HTML>
<html>
<head>
    <title>Cue Time Systems - Add Customer</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <style>
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .form-grid label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        .form-grid input[type="text"],
        .form-grid input[type="email"] {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .form-actions {
            text-align: center;
            margin-top: 30px;
        }
        .form-actions .button {
            font-size: 1.1rem;
            padding: 10px 24px;
            background-color: #87aa9f;
            border: none;
            color: white;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .form-actions .button:hover {
            background-color: #6e978a;
        }
        .main-header h1 {
            text-align: center;
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>

    <main class="main-content">
        <header class="main-header">
            <h1>Add New Customer</h1>
        </header>

        <div class="box">
            <form action="CustomerAddProcessing.php" method="post">
                <div class="form-grid">
                    <div>
                        <label for="FirstName">First Name:</label>
                        <input type="text" id="FirstName" name="FirstName" required>
                    </div>
                    <div>
                        <label for="LastName">Last Name:</label>
                        <input type="text" id="LastName" name="LastName" required>
                    </div>
                    <div>
                        <label for="PhoneNumber">Phone Number:</label>
                        <input type="text" id="PhoneNumber" name="PhoneNumber" required>
                    </div>
                    <div>
                        <label for="EmailAddress">Email Address:</label>
                        <input type="email" id="EmailAddress" name="EmailAddress" required>
                    </div>
                    <div>
                        <label for="LeagueName">League Name:</label>
                        <input type="text" id="LeagueName" name="LeagueName">
                    </div>
                </div>

                <div class="form-actions">
                    <input type="submit" value="Submit" class="button">
                </div>
            </form>
        </div>
    </main>
</body>
</html>


