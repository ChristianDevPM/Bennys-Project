<?php
header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=CustomerList.csv');

$server   = 'tcp:mis4173.database.windows.net,1433';
$database = 'bennys';
$username = 'bennysadmin';
$password = 'Poolhall1!';

$conn = new PDO("sqlsrv:Server=$server;Database=$database", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "SELECT FirstName, LastName, PhoneNumber, EmailAddress, LeagueName FROM customer";
$stmt = $conn->prepare($sql);
$stmt->execute();
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$output = fopen('php://output', 'w');

// Add column headers
fputcsv($output, ['First Name', 'Last Name', 'Phone Number', 'Email', 'League']);

foreach ($customers as $customer) {
    fputcsv($output, [
        $customer['FirstName'],
        $customer['LastName'],
        $customer['PhoneNumber'],
        $customer['EmailAddress'],
        $customer['LeagueName']
    ]);
}

fclose($output);
exit;
?>