<!-- sidebar.php -->
<div class="sidebar">
  <div>
    <div class="logo-container">
      <img src="images/CueTimelogo.png" alt="Cue Time Systems" class="logo" />
    </div>
    <nav>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="CustomerList.php">Customer List</a></li>
        
        <li><a href="SendPromoEmail.php">Send Benny's Specials</a></li>
        <li><a href="CustomerAdd.php">Add Customer</a></li>
        <li><a href="CustomerRentalSearch.php">Customer Rental Search</a></li>
        <li><a href="RentalSummaryReport.php">Rental Summary</a></li>
      </ul>
    </nav>
  </div>
  <div class="benny-logo-container">
    <img src="images/BennysLogo.png" alt="Benny's Logo" class="logo-benny" />
  </div>
</div>