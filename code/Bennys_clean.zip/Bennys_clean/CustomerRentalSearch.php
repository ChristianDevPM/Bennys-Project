<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Customer Rental Search</title>
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
  <?php include 'sidebar.php'; ?>
  <main class="main-content">
    <header class="main-header">
      <h1>Search Customer Rentals</h1>
    </header>

    <div class="report-box">
      <form action="CustomerRentalReport.php" method="post" class="report-filters" style="display: flex; gap: 10px;">
        <label for="search">Customer Name or Phone:</label>
        <input type="text" id="search" name="search" required>
        <button type="submit" class="button">Search</button>
      </form>
        
    </div>
  </main>
</body>
</html>